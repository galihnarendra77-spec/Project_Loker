-- Forgot Password System Database Schema
-- MariaDB / MySQL

-- Create database (run this first)
CREATE DATABASE IF NOT EXISTS forgot_password_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE forgot_password_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    nim VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_nim (nim)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin users table for secure admin authentication
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'superadmin') DEFAULT 'admin',
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL,
    login_attempts INT DEFAULT 0,
    locked_until TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample user for testing (password: TestPassword123!)
INSERT INTO users (email, password_hash) VALUES 
('test@example.com', '$2a$10$XQjZY5Z5Z5Z5Z5Z5Z5Z5ZeF5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z')
ON DUPLICATE KEY UPDATE email=email;

-- Insert default admin users (passwords are bcrypt hashed)
-- admin = password: admin123
-- superadmin = password: Super@2025
INSERT INTO admin_users (username, email, password_hash, name, role) VALUES 
('admin', 'admin@smartlocker.com', '$2a$10$lNKMzQG1emhzCuXsZc4c4wYSty3m6TZnzskDzUJhkEru', 'Administrator', 'admin'),
('superadmin', 'superadmin@smartlocker.com', '$2a$10$hKAXKQc9AJY', 'Super Admin', 'superadmin')
ON DUPLICATE KEY UPDATE username=username;
