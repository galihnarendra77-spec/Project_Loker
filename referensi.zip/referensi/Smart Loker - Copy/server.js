const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const { pool, testConnection } = require('./config/database');
const { client: redisClient, connectRedis } = require('./config/redis');
const { verifyEmailConnection, sendOTPEmail } = require('./config/email');
const { generateToken, verifyToken, requireRole } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 8888;
const OTP_EXPIRY = parseInt(process.env.OTP_EXPIRY_SECONDS) || 60;
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

// Security Middleware
app.use(helmet({
    contentSecurityPolicy: false, // Disable for development
    crossOriginEmbedderPolicy: false
}));

// CORS Configuration - Allow all origins for development
app.use(cors({
    origin: true,
    credentials: true
}));

// Rate Limiting for Login endpoints
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 attempts per window
    message: {
        success: false,
        message: 'Terlalu banyak percobaan login. Coba lagi dalam 15 menit.'
    },
    standardHeaders: true,
    legacyHeaders: false
});

// General API rate limiter
const apiLimiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 100, // 100 requests per minute
    message: {
        success: false,
        message: 'Terlalu banyak request. Coba lagi nanti.'
    }
});

app.use('/api/', apiLimiter);
app.use(express.json());
app.use(express.static(__dirname));

// Serve index.html at root
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Generate 6-digit OTP
function generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// API Endpoints

// 1. Request Password Reset - Send OTP via Email
app.post('/api/forgot-password', async (req, res) => {
    const { email } = req.body;

    try {
        // Validate email
        if (!email || !email.includes('@')) {
            return res.status(400).json({
                success: false,
                message: 'Email tidak valid'
            });
        }

        // Check if user exists in database
        const [users] = await pool.query('SELECT id, email FROM users WHERE email = ?', [email]);

        if (users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Email tidak terdaftar'
            });
        }

        // Generate OTP
        const otp = generateOTP();

        // Store OTP in Redis with expiry
        const redisKey = `otp:${email}`;
        await redisClient.setEx(redisKey, OTP_EXPIRY, otp);

        // Send OTP via email
        await sendOTPEmail(email, otp);

        // Only log OTP in development (never in production)
        if (!IS_PRODUCTION) {
            console.log(`🔑 OTP generated for ${email} (expires in ${OTP_EXPIRY}s)`);
        }

        res.json({
            success: true,
            message: 'Kode OTP telah dikirim ke email Anda',
            expirySeconds: OTP_EXPIRY
        });

    } catch (error) {
        console.error('Error in forgot-password:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengirim OTP'
        });
    }
});

// 2. Verify OTP
app.post('/api/verify-otp', async (req, res) => {
    const { email, otp } = req.body;

    try {
        // Validate input
        if (!email || !otp) {
            return res.status(400).json({
                success: false,
                message: 'Email dan OTP harus diisi'
            });
        }

        // Get OTP from Redis
        const redisKey = `otp:${email}`;
        const storedOTP = await redisClient.get(redisKey);

        if (!storedOTP) {
            return res.status(400).json({
                success: false,
                message: 'Kode OTP sudah kadaluarsa atau tidak valid'
            });
        }

        // Verify OTP
        if (storedOTP !== otp) {
            return res.status(400).json({
                success: false,
                message: 'Kode OTP salah'
            });
        }

        // OTP is valid - mark as verified in Redis (keep for password reset)
        await redisClient.setEx(`verified:${email}`, 300, 'true'); // 5 minutes to reset password

        res.json({
            success: true,
            message: 'Kode OTP berhasil diverifikasi'
        });

    } catch (error) {
        console.error('Error in verify-otp:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat verifikasi OTP'
        });
    }
});

// 3. Resend OTP
app.post('/api/resend-otp', async (req, res) => {
    const { email } = req.body;

    try {
        // Validate email
        if (!email || !email.includes('@')) {
            return res.status(400).json({
                success: false,
                message: 'Email tidak valid'
            });
        }

        // Check if user exists
        const [users] = await pool.query('SELECT id, email FROM users WHERE email = ?', [email]);

        if (users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Email tidak terdaftar'
            });
        }

        // Generate new OTP
        const otp = generateOTP();

        // Store OTP in Redis with expiry (overwrites old one)
        const redisKey = `otp:${email}`;
        await redisClient.setEx(redisKey, OTP_EXPIRY, otp);

        // Send OTP via email
        await sendOTPEmail(email, otp);

        // Only log in development
        if (!IS_PRODUCTION) {
            console.log(`🔑 OTP resent for ${email} (expires in ${OTP_EXPIRY}s)`);
        }

        res.json({
            success: true,
            message: 'Kode OTP baru telah dikirim ke email Anda',
            expirySeconds: OTP_EXPIRY
        });

    } catch (error) {
        console.error('Error in resend-otp:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengirim ulang OTP'
        });
    }
});

// 4. Reset Password
app.post('/api/reset-password', async (req, res) => {
    const { email, newPassword } = req.body;

    try {
        // Validate input
        if (!email || !newPassword) {
            return res.status(400).json({
                success: false,
                message: 'Email dan password baru harus diisi'
            });
        }

        // Check password strength
        if (newPassword.length < 8) {
            return res.status(400).json({
                success: false,
                message: 'Password minimal 8 karakter'
            });
        }

        // Check if OTP was verified
        const verifiedKey = `verified:${email}`;
        const isVerified = await redisClient.get(verifiedKey);

        if (!isVerified) {
            return res.status(400).json({
                success: false,
                message: 'Silakan verifikasi OTP terlebih dahulu'
            });
        }

        // Hash new password
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        // Update password in database
        const [result] = await pool.query(
            'UPDATE users SET password_hash = ?, updated_at = NOW() WHERE email = ?',
            [hashedPassword, email]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Email tidak terdaftar'
            });
        }

        // Clean up Redis keys
        await redisClient.del(`otp:${email}`);
        await redisClient.del(`verified:${email}`);

        console.log(`✅ Password reset successful for ${email}`);

        res.json({
            success: true,
            message: 'Password berhasil direset'
        });

    } catch (error) {
        console.error('Error in reset-password:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mereset password'
        });
    }
});

// ==================== USER REGISTRATION ====================

// 5. User Registration (Sign Up)
app.post('/api/register', async (req, res) => {
    const { name, nim, email, password } = req.body;

    try {
        // Validate input
        if (!name || !nim || !email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Semua field harus diisi (nama, NIM, email, password)'
            });
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: 'Format email tidak valid'
            });
        }

        // Validate NIM (only numbers)
        const nimRegex = /^[0-9]+$/;
        if (!nimRegex.test(nim)) {
            return res.status(400).json({
                success: false,
                message: 'NIM harus berupa angka'
            });
        }

        // Check password strength
        if (password.length < 8) {
            return res.status(400).json({
                success: false,
                message: 'Password minimal 8 karakter'
            });
        }

        // Check if email already exists
        const [existingEmail] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
        if (existingEmail.length > 0) {
            return res.status(409).json({
                success: false,
                message: 'Email sudah terdaftar'
            });
        }

        // Check if NIM already exists
        const [existingNIM] = await pool.query('SELECT id FROM users WHERE nim = ?', [nim]);
        if (existingNIM.length > 0) {
            return res.status(409).json({
                success: false,
                message: 'NIM sudah terdaftar'
            });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert new user
        const [result] = await pool.query(
            'INSERT INTO users (name, nim, email, password_hash) VALUES (?, ?, ?, ?)',
            [name.trim(), nim.trim(), email.toLowerCase().trim(), hashedPassword]
        );

        if (!IS_PRODUCTION) {
            console.log(`✅ New user registered: ${email}`);
        }

        res.status(201).json({
            success: true,
            message: 'Registrasi berhasil! Silakan login.',
            userId: result.insertId
        });

    } catch (error) {
        console.error('Error in registration:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat registrasi'
        });
    }
});

// 6. User Login
app.post('/api/user/login', loginLimiter, async (req, res) => {
    const { email, password } = req.body;

    try {
        // Validate input
        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Email dan password harus diisi'
            });
        }

        // Find user by email
        const [users] = await pool.query(
            'SELECT * FROM users WHERE email = ? AND is_active = TRUE',
            [email.toLowerCase().trim()]
        );

        if (users.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'Email atau password salah'
            });
        }

        const user = users[0];

        // Verify password
        const isValidPassword = await bcrypt.compare(password, user.password_hash);

        if (!isValidPassword) {
            return res.status(401).json({
                success: false,
                message: 'Email atau password salah'
            });
        }

        if (!IS_PRODUCTION) {
            console.log(`✅ User login successful: ${user.email}`);
        }

        res.json({
            success: true,
            message: 'Login berhasil',
            user: {
                id: user.id,
                name: user.name,
                nim: user.nim,
                email: user.email
            }
        });

    } catch (error) {
        console.error('Error in user login:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat login'
        });
    }
});

// 7. Update User Profile
app.put('/api/user/update-profile', async (req, res) => {
    const { userId, name, email } = req.body;

    try {
        // Validate input
        if (!userId || !name || !email) {
            return res.status(400).json({
                success: false,
                message: 'User ID, nama, dan email harus diisi'
            });
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: 'Format email tidak valid'
            });
        }

        // Check if email is already used by another user
        const [existingEmail] = await pool.query(
            'SELECT id FROM users WHERE email = ? AND id != ?',
            [email.toLowerCase().trim(), userId]
        );

        if (existingEmail.length > 0) {
            return res.status(409).json({
                success: false,
                message: 'Email sudah digunakan oleh pengguna lain'
            });
        }

        // Update user profile
        await pool.query(
            'UPDATE users SET name = ?, email = ?, updated_at = NOW() WHERE id = ?',
            [name.trim(), email.toLowerCase().trim(), userId]
        );

        if (!IS_PRODUCTION) {
            console.log(`✅ User profile updated: ${email}`);
        }

        res.json({
            success: true,
            message: 'Profil berhasil diperbarui',
            user: {
                id: userId,
                name: name.trim(),
                email: email.toLowerCase().trim()
            }
        });

    } catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat memperbarui profil'
        });
    }
});

// 8. Get User Profile
app.get('/api/user/profile', async (req, res) => {
    const { userId } = req.query;

    try {
        if (!userId) {
            return res.status(400).json({
                success: false,
                message: 'User ID diperlukan'
            });
        }

        const [users] = await pool.query(
            'SELECT id, name, nim, email, card_uid, is_active, created_at, updated_at FROM users WHERE id = ?',
            [userId]
        );

        if (users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'User tidak ditemukan'
            });
        }

        const user = users[0];

        res.json({
            success: true,
            user: {
                id: user.id,
                name: user.name,
                nim: user.nim,
                email: user.email,
                hasCard: !!user.card_uid,
                isActive: user.is_active,
                createdAt: user.created_at,
                updatedAt: user.updated_at
            }
        });

    } catch (error) {
        console.error('Error getting user profile:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil profil'
        });
    }
});

// 9. Change Password
app.post('/api/user/change-password', async (req, res) => {
    const { userId, currentPassword, newPassword } = req.body;

    try {
        // Validate input
        if (!userId || !currentPassword || !newPassword) {
            return res.status(400).json({
                success: false,
                message: 'User ID, password lama, dan password baru harus diisi'
            });
        }

        // Check new password strength
        if (newPassword.length < 8) {
            return res.status(400).json({
                success: false,
                message: 'Password baru minimal 8 karakter'
            });
        }

        // Get current user
        const [users] = await pool.query(
            'SELECT id, password_hash FROM users WHERE id = ?',
            [userId]
        );

        if (users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'User tidak ditemukan'
            });
        }

        const user = users[0];

        // Verify current password
        const isValidPassword = await bcrypt.compare(currentPassword, user.password_hash);

        if (!isValidPassword) {
            return res.status(401).json({
                success: false,
                message: 'Password lama salah'
            });
        }

        // Hash new password
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        // Update password
        await pool.query(
            'UPDATE users SET password_hash = ?, updated_at = NOW() WHERE id = ?',
            [hashedPassword, userId]
        );

        if (!IS_PRODUCTION) {
            console.log(`✅ Password changed for user ID: ${userId}`);
        }

        res.json({
            success: true,
            message: 'Password berhasil diubah'
        });

    } catch (error) {
        console.error('Error changing password:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengubah password'
        });
    }
});

// ==================== ADMIN AUTHENTICATION ====================

// Admin Login with JWT
app.post('/api/admin/login', loginLimiter, async (req, res) => {
    const { username, password } = req.body;

    try {
        // Validate input  
        if (!username || !password) {
            return res.status(400).json({
                success: false,
                message: 'Username dan password harus diisi'
            });
        }

        // Find admin by username or email
        const [admins] = await pool.query(
            'SELECT * FROM admin_users WHERE (username = ? OR email = ?) AND is_active = TRUE',
            [username.toLowerCase(), username.toLowerCase()]
        );

        if (admins.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'Username atau password salah'
            });
        }

        const admin = admins[0];

        // Check if account is locked
        if (admin.locked_until && new Date(admin.locked_until) > new Date()) {
            const lockRemaining = Math.ceil((new Date(admin.locked_until) - new Date()) / 60000);
            return res.status(423).json({
                success: false,
                message: `Akun terkunci. Coba lagi dalam ${lockRemaining} menit.`
            });
        }

        // Verify password
        const isValidPassword = await bcrypt.compare(password, admin.password_hash);

        if (!isValidPassword) {
            // Increment login attempts
            const newAttempts = admin.login_attempts + 1;

            if (newAttempts >= 5) {
                // Lock account for 30 minutes
                await pool.query(
                    'UPDATE admin_users SET login_attempts = ?, locked_until = DATE_ADD(NOW(), INTERVAL 30 MINUTE) WHERE id = ?',
                    [newAttempts, admin.id]
                );
                return res.status(423).json({
                    success: false,
                    message: 'Akun terkunci karena terlalu banyak percobaan. Coba lagi dalam 30 menit.'
                });
            } else {
                await pool.query(
                    'UPDATE admin_users SET login_attempts = ? WHERE id = ?',
                    [newAttempts, admin.id]
                );
            }

            return res.status(401).json({
                success: false,
                message: 'Username atau password salah',
                attemptsRemaining: 5 - newAttempts
            });
        }

        // Reset login attempts and update last login
        await pool.query(
            'UPDATE admin_users SET login_attempts = 0, locked_until = NULL, last_login = NOW() WHERE id = ?',
            [admin.id]
        );

        // Generate JWT token
        const token = generateToken(admin);

        // Log successful login (not showing sensitive data in production)
        if (!IS_PRODUCTION) {
            console.log(`✅ Admin login successful: ${admin.username}`);
        }

        res.json({
            success: true,
            message: 'Login berhasil',
            token: token,
            admin: {
                id: admin.id,
                username: admin.username,
                name: admin.name,
                email: admin.email,
                role: admin.role
            }
        });

    } catch (error) {
        console.error('Error in admin login:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat login'
        });
    }
});

// Verify Admin Token
app.get('/api/admin/verify', verifyToken, (req, res) => {
    res.json({
        success: true,
        message: 'Token valid',
        admin: req.admin
    });
});

// Get Admin Profile (Protected)
app.get('/api/admin/profile', verifyToken, async (req, res) => {
    try {
        const [admins] = await pool.query(
            'SELECT id, username, email, name, role, last_login, created_at FROM admin_users WHERE id = ?',
            [req.admin.id]
        );

        if (admins.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Admin tidak ditemukan'
            });
        }

        res.json({
            success: true,
            admin: admins[0]
        });
    } catch (error) {
        console.error('Error getting admin profile:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan'
        });
    }
});

// Admin Logout (invalidate on client side)
app.post('/api/admin/logout', verifyToken, (req, res) => {
    // JWT tokens are stateless, logout is handled client-side
    // For extra security, you could store invalidated tokens in Redis
    if (!IS_PRODUCTION) {
        console.log(`🚪 Admin logout: ${req.admin.username}`);
    }

    res.json({
        success: true,
        message: 'Logout berhasil'
    });
});

// ==================== CARD MANAGEMENT ====================

// Get user's card status
app.get('/api/user/card-status', async (req, res) => {
    const { userId } = req.query;

    try {
        if (!userId) {
            return res.status(400).json({
                success: false,
                message: 'User ID diperlukan'
            });
        }

        const [users] = await pool.query(
            'SELECT card_uid FROM users WHERE id = ?',
            [userId]
        );

        if (users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'User tidak ditemukan'
            });
        }

        const hasCard = !!users[0].card_uid;

        res.json({
            success: true,
            hasCard: hasCard,
            cardUid: hasCard ? users[0].card_uid : null
        });

    } catch (error) {
        console.error('Error getting card status:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengecek status kartu'
        });
    }
});

// Start card sync
app.post('/api/card/start-sync', async (req, res) => {
    const { userId } = req.body;

    try {
        if (!userId) {
            return res.status(400).json({
                success: false,
                message: 'User ID diperlukan'
            });
        }

        console.log(`🔄 Card sync started for user: ${userId}`);

        res.json({
            success: true,
            message: 'Sinkronisasi dimulai, silakan tempelkan kartu'
        });

    } catch (error) {
        console.error('Error starting card sync:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat memulai sinkronisasi'
        });
    }
});

// Save card UID to user
app.post('/api/card/save', async (req, res) => {
    const { userId, cardUid } = req.body;

    try {
        if (!userId || !cardUid) {
            return res.status(400).json({
                success: false,
                message: 'User ID dan Card UID diperlukan'
            });
        }

        const [existingCards] = await pool.query(
            'SELECT id FROM users WHERE card_uid = ? AND id != ?',
            [cardUid, userId]
        );

        if (existingCards.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Kartu ini sudah terdaftar pada akun lain'
            });
        }

        await pool.query(
            'UPDATE users SET card_uid = ? WHERE id = ?',
            [cardUid, userId]
        );

        console.log(`✅ Card ${cardUid} saved for user ${userId}`);

        res.json({
            success: true,
            message: 'Kartu berhasil didaftarkan'
        });

    } catch (error) {
        console.error('Error saving card:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat menyimpan kartu'
        });
    }
});

// Reset card
app.post('/api/card/reset', async (req, res) => {
    const { email, otp } = req.body;

    try {
        if (!email || !otp) {
            return res.status(400).json({
                success: false,
                message: 'Email dan OTP diperlukan'
            });
        }

        const storedOTP = await redisClient.get(`otp:${email}`);

        if (!storedOTP || storedOTP !== otp) {
            return res.status(400).json({
                success: false,
                message: 'Kode OTP tidak valid atau sudah kedaluwarsa'
            });
        }

        await pool.query(
            'UPDATE users SET card_uid = NULL WHERE email = ?',
            [email]
        );

        await redisClient.del(`otp:${email}`);

        console.log(`✅ Card reset for user: ${email}`);

        res.json({
            success: true,
            message: 'Kartu berhasil direset'
        });

    } catch (error) {
        console.error('Error resetting card:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mereset kartu'
        });
    }
});

// Generate temporary PIN
app.post('/api/card/get-pin', async (req, res) => {
    const { email, otp } = req.body;

    try {
        if (!email || !otp) {
            return res.status(400).json({
                success: false,
                message: 'Email dan OTP diperlukan'
            });
        }

        const storedOTP = await redisClient.get(`otp:${email}`);

        if (!storedOTP || storedOTP !== otp) {
            return res.status(400).json({
                success: false,
                message: 'Kode OTP tidak valid atau sudah kedaluwarsa'
            });
        }

        const pin = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 15 * 60 * 1000);

        await pool.query(
            'UPDATE users SET temp_pin = ?, temp_pin_expires = ? WHERE email = ?',
            [pin, expiresAt, email]
        );

        await redisClient.del(`otp:${email}`);

        console.log(`✅ Temporary PIN generated for user: ${email}`);

        res.json({
            success: true,
            message: 'PIN sementara berhasil dibuat',
            pin: pin
        });

    } catch (error) {
        console.error('Error generating PIN:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat membuat PIN'
        });
    }
});

// Verify PIN (for ESP32/Raspberry Pi)
app.post('/api/card/verify-pin', async (req, res) => {
    const { pin } = req.body;

    try {
        if (!pin) {
            return res.status(400).json({
                success: false,
                message: 'PIN diperlukan'
            });
        }

        const [users] = await pool.query(
            'SELECT id, email FROM users WHERE temp_pin = ? AND temp_pin_expires > NOW()',
            [pin]
        );

        if (users.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'PIN tidak valid atau sudah kedaluwarsa'
            });
        }

        const user = users[0];

        await pool.query(
            'UPDATE users SET temp_pin = NULL, temp_pin_expires = NULL WHERE id = ?',
            [user.id]
        );

        console.log(`✅ PIN verified for user: ${user.email}`);

        res.json({
            success: true,
            message: 'PIN valid',
            userId: user.id
        });

    } catch (error) {
        console.error('Error verifying PIN:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat verifikasi PIN'
        });
    }
});

// ==================== HEALTH CHECK ====================

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        message: 'Server is running',
        timestamp: new Date().toISOString()
    });
});

// Debug: List registered users (DEVELOPMENT ONLY - protected in production)
app.get('/api/debug/users', async (req, res) => {
    // Block access in production
    if (IS_PRODUCTION) {
        return res.status(403).json({
            success: false,
            message: 'Debug endpoint disabled in production'
        });
    }

    try {
        const [users] = await pool.query(
            'SELECT id, name, nim, email, is_active, created_at FROM users ORDER BY created_at DESC LIMIT 20'
        );
        res.json({
            success: true,
            count: users.length,
            users: users
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

// Initialize server
async function startServer() {
    try {
        // Test database connection
        await testConnection();

        // Auto-migrate users table if needed
        await migrateUsersTable();

        // Connect to Redis
        await connectRedis();

        // Verify email connection
        await verifyEmailConnection();

        // Start Express server
        app.listen(PORT, () => {
            console.log(`\n🚀 Server running on http://localhost:${PORT}`);
            console.log(`📱 Frontend: http://localhost:${PORT}`);
            console.log(`🔌 API: http://localhost:${PORT}/api`);
        });
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
}

// Auto-migrate users table to add missing columns
async function migrateUsersTable() {
    try {
        // Check if users table exists, if not create it
        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL DEFAULT 'User',
                nim VARCHAR(50) NULL,
                email VARCHAR(255) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_email (email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        `);

        // Check and add missing columns
        const [columns] = await pool.query(`
            SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users'
        `);

        const existingColumns = columns.map(c => c.COLUMN_NAME.toLowerCase());

        // Add name column if missing
        if (!existingColumns.includes('name')) {
            await pool.query("ALTER TABLE users ADD COLUMN name VARCHAR(100) NOT NULL DEFAULT 'User' AFTER id");
            console.log('✅ Added name column to users table');
        }

        // Add nim column if missing
        if (!existingColumns.includes('nim')) {
            await pool.query("ALTER TABLE users ADD COLUMN nim VARCHAR(50) NULL AFTER name");
            console.log('✅ Added nim column to users table');
        }

        // Add is_active column if missing
        if (!existingColumns.includes('is_active')) {
            await pool.query("ALTER TABLE users ADD COLUMN is_active BOOLEAN DEFAULT TRUE AFTER password_hash");
            console.log('✅ Added is_active column to users table');
        }

        // Add card_uid column if missing
        if (!existingColumns.includes('card_uid')) {
            await pool.query("ALTER TABLE users ADD COLUMN card_uid VARCHAR(50) DEFAULT NULL AFTER is_active");
            console.log('✅ Added card_uid column to users table');
        }

        // Add temp_pin column if missing
        if (!existingColumns.includes('temp_pin')) {
            await pool.query("ALTER TABLE users ADD COLUMN temp_pin VARCHAR(10) DEFAULT NULL AFTER card_uid");
            console.log('✅ Added temp_pin column to users table');
        }

        // Add temp_pin_expires column if missing
        if (!existingColumns.includes('temp_pin_expires')) {
            await pool.query("ALTER TABLE users ADD COLUMN temp_pin_expires TIMESTAMP NULL AFTER temp_pin");
            console.log('✅ Added temp_pin_expires column to users table');
        }

        console.log('✅ Users table migration complete');
    } catch (error) {
        console.error('Error migrating users table:', error);
        // Don't exit, just log the error
    }
}

startServer();
