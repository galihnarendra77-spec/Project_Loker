// Script to generate bcrypt password hashes
// Run: node generate-hash.js

const bcrypt = require('bcryptjs');

async function generateHashes() {
    const passwords = [
        { name: 'admin', password: 'admin123' },
        { name: 'superadmin', password: 'Super@2025' }
    ];

    console.log('\n=== Generated Password Hashes ===\n');

    for (const user of passwords) {
        const hash = await bcrypt.hash(user.password, 10);
        console.log(`User: ${user.name}`);
        console.log(`Password: ${user.password}`);
        console.log(`Hash: ${hash}`);
        console.log('---');
    }

    console.log('\nCopy these hashes to your database SQL INSERT statement.');
    console.log('Or run the schema.sql in your MySQL client (phpMyAdmin, HeidiSQL, etc.)\n');
}

generateHashes();
