// ==================== Smart Locker Dashboard Script ====================

// Get user data from session/localStorage
function getUserData() {
    const sessionUser = sessionStorage.getItem('user');
    const localUser = localStorage.getItem('user');

    if (sessionUser) {
        return JSON.parse(sessionUser);
    } else if (localUser) {
        return JSON.parse(localUser);
    }
    return null;
}

// Check if user is logged in
function checkAuth() {
    const user = getUserData();
    if (!user) {
        // Redirect to login if not authenticated
        window.location.href = 'index.html';
        return null;
    }
    return user;
}

// Initialize user info display
function initUserInfo() {
    const user = checkAuth();
    if (!user) return;

    // Update all user name displays
    const welcomeName = document.getElementById('welcomeUserName');
    const navUserName = document.getElementById('navUserName');
    const sidebarUserName = document.getElementById('sidebarUserName');
    const sidebarUserNim = document.getElementById('sidebarUserNim');

    if (welcomeName) welcomeName.textContent = user.name || 'User';
    if (navUserName) navUserName.textContent = user.name || 'User';
    if (sidebarUserName) sidebarUserName.textContent = user.name || 'User';
    if (sidebarUserNim) sidebarUserNim.textContent = `NIM: ${user.nim || '-'}`;
}

// Format time
function formatTime(date) {
    return date.toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
    });
}

// Format date
function formatDate(date) {
    return date.toLocaleDateString('id-ID', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });
}

// Update clock
function updateClock() {
    const now = new Date();
    const timeDisplay = document.getElementById('currentTime');
    const dateDisplay = document.getElementById('currentDate');

    if (timeDisplay) timeDisplay.textContent = formatTime(now);
    if (dateDisplay) dateDisplay.textContent = formatDate(now);
}

// Toast notification
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
        <span>${message}</span>
    `;

    container.appendChild(toast);

    // Remove after animation
    setTimeout(() => {
        toast.remove();
    }, 3500);
}

// Locker data (simulated - in real app would come from backend)
let lockers = [];
let userActiveLocker = null;

function initLockers() {
    // Initialize 10 lockers
    lockers = Array.from({ length: 10 }, (_, i) => ({
        id: i + 1,
        status: Math.random() > 0.5 ? 'available' : 'occupied',
        userId: null
    }));

    // Check if user has saved locker in localStorage
    const savedLocker = localStorage.getItem('userActiveLocker');
    if (savedLocker) {
        const lockerData = JSON.parse(savedLocker);
        userActiveLocker = lockerData;

        // Mark that locker as user's
        const locker = lockers.find(l => l.id === lockerData.lockerId);
        if (locker) {
            locker.status = 'yours';
            locker.userId = getUserData()?.id;
        }
    }

    renderLockers();
    updateStats();
    updateActiveLockerCard();
}

function renderLockers() {
    const grid = document.getElementById('lockerGrid');
    if (!grid) return;

    grid.innerHTML = '';

    lockers.forEach(locker => {
        const box = document.createElement('div');
        box.className = `locker-box ${locker.status === 'occupied' ? 'occupied' : ''} ${locker.status === 'yours' ? 'yours' : ''}`;
        box.innerHTML = `
            <div class="locker-number">${locker.id}</div>
            <div class="locker-status">${getStatusText(locker.status)}</div>
        `;

        if (locker.status === 'available') {
            box.onclick = () => openBookingModal(locker.id);
        } else if (locker.status === 'yours') {
            box.onclick = () => showToast('Ini adalah locker Anda saat ini', 'info');
        }

        grid.appendChild(box);
    });
}

function getStatusText(status) {
    switch (status) {
        case 'available': return 'Tersedia';
        case 'occupied': return 'Terisi';
        case 'yours': return 'Milik Anda';
        default: return status;
    }
}

function updateStats() {
    const total = lockers.length;
    const available = lockers.filter(l => l.status === 'available').length;
    const occupied = lockers.filter(l => l.status === 'occupied' || l.status === 'yours').length;

    const totalEl = document.getElementById('totalCount');
    const availableEl = document.getElementById('availableCount');
    const occupiedEl = document.getElementById('occupiedCount');

    if (totalEl) totalEl.textContent = total;
    if (availableEl) availableEl.textContent = available;
    if (occupiedEl) occupiedEl.textContent = occupied;
}

function updateActiveLockerCard() {
    const card = document.getElementById('activeLockerCard');
    if (!card) return;

    if (userActiveLocker) {
        card.style.display = 'block';

        document.getElementById('activeLockerNumber').textContent = userActiveLocker.lockerId;
        document.getElementById('startTime').textContent = userActiveLocker.startTime;
        document.getElementById('duration').textContent = calculateDuration(userActiveLocker.startTimestamp);
    } else {
        card.style.display = 'none';
    }
}

function calculateDuration(startTimestamp) {
    const start = new Date(startTimestamp);
    const now = new Date();
    const diff = now - start;

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    if (hours > 0) {
        return `${hours} jam ${minutes} menit`;
    }
    return `${minutes} menit`;
}

// Booking Modal
let selectedLockerId = null;

function openBookingModal(lockerId) {
    if (userActiveLocker) {
        showToast('Anda sudah memiliki locker aktif. Kembalikan terlebih dahulu.', 'error');
        return;
    }

    selectedLockerId = lockerId;

    document.getElementById('modalLockerNumber').textContent = lockerId;
    document.getElementById('modalLockerText').textContent = lockerId;

    const modal = document.getElementById('bookingModal');
    modal.classList.add('active');
}

function closeBookingModal() {
    const modal = document.getElementById('bookingModal');
    modal.classList.remove('active');
    selectedLockerId = null;
}

function confirmBooking() {
    if (!selectedLockerId) return;

    const now = new Date();

    // Update locker status
    const locker = lockers.find(l => l.id === selectedLockerId);
    if (locker) {
        locker.status = 'yours';
        locker.userId = getUserData()?.id;
    }

    // Save active locker
    userActiveLocker = {
        lockerId: selectedLockerId,
        startTime: formatTime(now),
        startTimestamp: now.toISOString()
    };

    localStorage.setItem('userActiveLocker', JSON.stringify(userActiveLocker));

    // Update UI
    renderLockers();
    updateStats();
    updateActiveLockerCard();
    closeBookingModal();

    showToast(`Berhasil booking Locker #${selectedLockerId}!`, 'success');
}

function releaseLocker() {
    if (!userActiveLocker) return;

    // Update locker status
    const locker = lockers.find(l => l.id === userActiveLocker.lockerId);
    if (locker) {
        locker.status = 'available';
        locker.userId = null;
    }

    // Clear active locker
    localStorage.removeItem('userActiveLocker');
    userActiveLocker = null;

    // Update UI
    renderLockers();
    updateStats();
    updateActiveLockerCard();

    showToast('Locker berhasil dikembalikan!', 'success');
}

// Help Modal
function openHelpModal() {
    const modal = document.getElementById('helpModal');
    modal.classList.add('active');
}

function closeHelpModal() {
    const modal = document.getElementById('helpModal');
    modal.classList.remove('active');
}

// Logout function
function logout() {
    // Clear user data
    sessionStorage.removeItem('user');
    localStorage.removeItem('user');
    localStorage.removeItem('userActiveLocker');

    showToast('Logout berhasil!', 'success');

    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1000);
}

// Sidebar toggle
function initSidebar() {
    const threeDotsMenu = document.getElementById('threeDotsMenu');
    const sidebarPopup = document.getElementById('sidebarPopup');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const sidebarClose = document.getElementById('sidebarClose');

    function openSidebar() {
        sidebarPopup.classList.add('active');
        sidebarOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeSidebar() {
        sidebarPopup.classList.remove('active');
        sidebarOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    if (threeDotsMenu) threeDotsMenu.addEventListener('click', openSidebar);
    if (sidebarClose) sidebarClose.addEventListener('click', closeSidebar);
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);
}

// User dropdown toggle
function initUserDropdown() {
    const userMenu = document.getElementById('userMenu');
    const userDropdown = document.getElementById('userDropdown');

    if (userMenu && userDropdown) {
        userMenu.addEventListener('click', (e) => {
            e.stopPropagation();
            userMenu.classList.toggle('active');
            userDropdown.classList.toggle('active');
        });

        document.addEventListener('click', () => {
            userMenu.classList.remove('active');
            userDropdown.classList.remove('active');
        });
    }
}

// Initialize everything on DOM ready
document.addEventListener('DOMContentLoaded', function () {
    // Check authentication first
    const user = checkAuth();
    if (!user) return;

    // Initialize user info
    initUserInfo();

    // Start clock
    updateClock();
    setInterval(updateClock, 1000);

    // Initialize lockers
    initLockers();

    // Initialize sidebar
    initSidebar();

    // Initialize user dropdown
    initUserDropdown();

    // Event listeners for modals
    const closeModalBtn = document.getElementById('closeModal');
    const cancelBookingBtn = document.getElementById('cancelBooking');
    const confirmBookingBtn = document.getElementById('confirmBooking');
    const releaseBtnEl = document.getElementById('releaseBtn');
    const helpBtn = document.getElementById('helpBtn');
    const bookLockerBtn = document.getElementById('bookLockerBtn');
    const closeHelpModalBtn = document.getElementById('closeHelpModal');
    const closeHelpBtn = document.getElementById('closeHelpBtn');

    if (closeModalBtn) closeModalBtn.addEventListener('click', closeBookingModal);
    if (cancelBookingBtn) cancelBookingBtn.addEventListener('click', closeBookingModal);
    if (confirmBookingBtn) confirmBookingBtn.addEventListener('click', confirmBooking);
    if (releaseBtnEl) releaseBtnEl.addEventListener('click', releaseLocker);
    if (helpBtn) helpBtn.addEventListener('click', openHelpModal);
    if (closeHelpModalBtn) closeHelpModalBtn.addEventListener('click', closeHelpModal);
    if (closeHelpBtn) closeHelpBtn.addEventListener('click', closeHelpModal);

    // Book locker quick action - find first available
    if (bookLockerBtn) {
        bookLockerBtn.addEventListener('click', () => {
            const availableLocker = lockers.find(l => l.status === 'available');
            if (availableLocker) {
                openBookingModal(availableLocker.id);
            } else {
                showToast('Tidak ada locker tersedia saat ini', 'error');
            }
        });
    }

    // Logout buttons
    const logoutBtn = document.getElementById('logoutBtn');
    const logoutBtnDesktop = document.getElementById('logoutBtnDesktop');

    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    }

    if (logoutBtnDesktop) {
        logoutBtnDesktop.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    }

    // Close modals on escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeBookingModal();
            closeHelpModal();
        }
    });

    // Close modals on overlay click
    document.getElementById('bookingModal')?.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal-overlay')) {
            closeBookingModal();
        }
    });

    document.getElementById('helpModal')?.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal-overlay')) {
            closeHelpModal();
        }
    });

    // Update duration every minute
    setInterval(() => {
        if (userActiveLocker) {
            document.getElementById('duration').textContent = calculateDuration(userActiveLocker.startTimestamp);
        }
    }, 60000);

    console.log('✅ Smart Locker Dashboard initialized');
});
