// Admin Dashboard JavaScript - Enhanced Version

document.addEventListener('DOMContentLoaded', function () {
    initSidebar();
    initNavigation();
    initNotifications();
    initCharts();
    initLockerManagement();
    initClock();
    initThemeToggle();
    initFullscreen();
    initProfileDropdown();
    initTableActions();
    initExportButtons();
    checkAdminSession();
});

// ==================== ADMIN SESSION ====================
function checkAdminSession() {
    // Check if admin is logged in
    const isLoggedIn = localStorage.getItem('adminLoggedIn');
    const adminName = localStorage.getItem('adminName') || 'Administrator';

    if (isLoggedIn !== 'true') {
        // Redirect to admin login if not logged in
        // window.location.href = 'admin-login.html';
    }

    // Update admin name in UI
    const adminNameElements = document.querySelectorAll('.admin-name, #adminName, #dropdownAdminName');
    adminNameElements.forEach(el => {
        if (el) el.textContent = adminName;
    });
}

// ==================== REAL-TIME CLOCK ====================
function initClock() {
    const timeElement = document.getElementById('currentTime');
    const dateElement = document.getElementById('currentDate');

    function updateClock() {
        const now = new Date();

        if (timeElement) {
            timeElement.textContent = now.toLocaleTimeString('id-ID', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
        }

        if (dateElement) {
            dateElement.textContent = now.toLocaleDateString('id-ID', {
                day: '2-digit',
                month: 'short',
                year: 'numeric'
            });
        }
    }

    updateClock();
    setInterval(updateClock, 1000);
}

// ==================== THEME TOGGLE ====================
function initThemeToggle() {
    const themeToggle = document.getElementById('themeToggle');
    const savedTheme = localStorage.getItem('adminTheme') || 'dark';

    // Apply saved theme
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
        if (themeToggle) {
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        }
    }

    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            document.body.classList.toggle('light-theme');
            const isLight = document.body.classList.contains('light-theme');
            themeToggle.innerHTML = isLight ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
            localStorage.setItem('adminTheme', isLight ? 'light' : 'dark');
            showToast(isLight ? 'Mode terang diaktifkan' : 'Mode gelap diaktifkan', 'info');
        });
    }
}

// ==================== FULLSCREEN TOGGLE ====================
function initFullscreen() {
    const fullscreenToggle = document.getElementById('fullscreenToggle');

    if (fullscreenToggle) {
        fullscreenToggle.addEventListener('click', () => {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().then(() => {
                    fullscreenToggle.innerHTML = '<i class="fas fa-compress"></i>';
                });
            } else {
                document.exitFullscreen().then(() => {
                    fullscreenToggle.innerHTML = '<i class="fas fa-expand"></i>';
                });
            }
        });
    }

    document.addEventListener('fullscreenchange', () => {
        if (fullscreenToggle) {
            fullscreenToggle.innerHTML = document.fullscreenElement
                ? '<i class="fas fa-compress"></i>'
                : '<i class="fas fa-expand"></i>';
        }
    });
}

// ==================== PROFILE DROPDOWN ====================
function initProfileDropdown() {
    const adminProfile = document.getElementById('adminProfile');
    const profileDropdown = document.getElementById('profileDropdown');

    if (adminProfile && profileDropdown) {
        adminProfile.addEventListener('click', (e) => {
            e.stopPropagation();
            profileDropdown.classList.toggle('show');
        });

        document.addEventListener('click', (e) => {
            if (!profileDropdown.contains(e.target) && !adminProfile.contains(e.target)) {
                profileDropdown.classList.remove('show');
            }
        });
    }
}

// ==================== SIDEBAR ====================
function initSidebar() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const menuToggle = document.getElementById('menuToggle');

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        });
    }

    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('show');
        });
    }

    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 992) {
            if (sidebar && menuToggle && !sidebar.contains(e.target) && !menuToggle.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        }
    });

    if (localStorage.getItem('sidebarCollapsed') === 'true' && sidebar) {
        sidebar.classList.add('collapsed');
    }
}

// ==================== NAVIGATION ====================
function initNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const pageName = item.dataset.page;
            navigateTo(pageName);
        });
    });

    if (window.location.hash) {
        const hash = window.location.hash.substring(1);
        navigateTo(hash);
    }
}

function navigateTo(pageName) {
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page');

    navItems.forEach(nav => nav.classList.remove('active'));
    const activeNav = document.querySelector(`[data-page="${pageName}"]`);
    if (activeNav) activeNav.classList.add('active');

    pages.forEach(page => {
        page.classList.remove('active');
        if (page.id === `${pageName}Page`) {
            page.classList.add('active');
        }
    });

    if (window.innerWidth <= 992) {
        const sidebar = document.getElementById('sidebar');
        if (sidebar) sidebar.classList.remove('show');
    }

    // Close profile dropdown
    const profileDropdown = document.getElementById('profileDropdown');
    if (profileDropdown) profileDropdown.classList.remove('show');
}

// ==================== NOTIFICATIONS ====================
function initNotifications() {
    const notificationBtn = document.getElementById('notificationBtn');
    const notificationDropdown = document.getElementById('notificationDropdown');

    if (notificationBtn && notificationDropdown) {
        notificationBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            notificationDropdown.classList.toggle('show');
        });

        document.addEventListener('click', (e) => {
            if (!notificationDropdown.contains(e.target)) {
                notificationDropdown.classList.remove('show');
            }
        });
    }
}

function markAllRead() {
    const unreadItems = document.querySelectorAll('.notification-item.unread');
    unreadItems.forEach(item => item.classList.remove('unread'));

    const badge = document.querySelector('.notification-badge');
    if (badge) badge.style.display = 'none';

    showToast('Semua notifikasi telah ditandai dibaca', 'success');
}

function viewAllNotifications() {
    showToast('Fitur sedang dalam pengembangan', 'info');
}

// ==================== CHARTS ====================
function initCharts() {
    initUsageChart();
    initStatusChart();
}

function initUsageChart() {
    const ctx = document.getElementById('usageChart');
    if (!ctx) return;

    const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 300);
    gradient.addColorStop(0, 'rgba(91, 134, 229, 0.5)');
    gradient.addColorStop(1, 'rgba(91, 134, 229, 0)');

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'],
            datasets: [{
                label: 'Peminjaman',
                data: [12, 19, 15, 25, 22, 18, 10],
                fill: true,
                backgroundColor: gradient,
                borderColor: '#5B86E5',
                borderWidth: 3,
                tension: 0.4,
                pointBackgroundColor: '#5B86E5',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }, {
                label: 'Pengembalian',
                data: [10, 15, 12, 20, 18, 16, 8],
                fill: false,
                borderColor: '#36D1DC',
                borderWidth: 3,
                tension: 0.4,
                pointBackgroundColor: '#36D1DC',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        color: '#94a3b8',
                        usePointStyle: true,
                        padding: 20
                    }
                }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255, 255, 255, 0.05)' },
                    ticks: { color: '#94a3b8' }
                },
                y: {
                    grid: { color: 'rgba(255, 255, 255, 0.05)' },
                    ticks: { color: '#94a3b8' }
                }
            },
            interaction: { intersect: false, mode: 'index' }
        }
    });
}

function initStatusChart() {
    const ctx = document.getElementById('statusChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Tersedia', 'Terpakai', 'Pemeliharaan'],
            datasets: [{
                data: [8, 7, 0],
                backgroundColor: ['#4ade80', '#f87171', '#fbbf24'],
                borderWidth: 0,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    labels: { color: '#94a3b8', usePointStyle: true, padding: 20 }
                }
            }
        }
    });
}

// ==================== LOCKER MANAGEMENT ====================
function initLockerManagement() {
    const lockerGrid = document.querySelector('.locker-management-grid');
    if (!lockerGrid) return;

    const lockers = [
        { id: 1, status: 'available', location: 'Lantai 1', lastUsed: '5 Des 2024' },
        { id: 2, status: 'occupied', location: 'Lantai 1', user: 'Ahmad Rifai', lastUsed: '5 Des 2024' },
        { id: 3, status: 'available', location: 'Lantai 1', lastUsed: '4 Des 2024' },
        { id: 4, status: 'occupied', location: 'Lantai 1', user: 'Rizky Pratama', lastUsed: '5 Des 2024' },
        { id: 5, status: 'available', location: 'Lantai 1', lastUsed: '5 Des 2024' },
        { id: 6, status: 'available', location: 'Lantai 2', lastUsed: '3 Des 2024' },
        { id: 7, status: 'occupied', location: 'Lantai 2', user: 'Dewi Lestari', lastUsed: '4 Des 2024' },
        { id: 8, status: 'occupied', location: 'Lantai 2', user: 'Siti Nurhaliza', lastUsed: '5 Des 2024' },
        { id: 9, status: 'available', location: 'Lantai 2', lastUsed: '2 Des 2024' },
        { id: 10, status: 'occupied', location: 'Lantai 2', user: 'Budi Santoso', lastUsed: '5 Des 2024' },
        { id: 11, status: 'available', location: 'Lantai 3', lastUsed: '1 Des 2024' },
        { id: 12, status: 'occupied', location: 'Lantai 3', user: 'Dewi Lestari', lastUsed: '4 Des 2024' },
        { id: 13, status: 'available', location: 'Lantai 3', lastUsed: '30 Nov 2024' },
        { id: 14, status: 'occupied', location: 'Lantai 3', user: 'Andi Wijaya', lastUsed: '5 Des 2024' },
        { id: 15, status: 'available', location: 'Lantai 3', lastUsed: '29 Nov 2024' }
    ];

    lockerGrid.innerHTML = lockers.map(locker => createLockerCard(locker)).join('');
}

function createLockerCard(locker) {
    const statusText = {
        'available': 'Tersedia',
        'occupied': 'Terpakai',
        'maintenance': 'Pemeliharaan'
    };

    return `
        <div class="locker-card ${locker.status}">
            <div class="locker-card-header">
                <div class="locker-number-badge">${locker.id}</div>
                <span class="locker-status-badge">${statusText[locker.status]}</span>
            </div>
            <div class="locker-card-body">
                <div class="locker-info-row">
                    <span>Lokasi</span>
                    <span>${locker.location}</span>
                </div>
                ${locker.user ? `
                <div class="locker-info-row">
                    <span>Pengguna</span>
                    <span>${locker.user}</span>
                </div>
                ` : ''}
                <div class="locker-info-row">
                    <span>Terakhir Digunakan</span>
                    <span>${locker.lastUsed}</span>
                </div>
            </div>
            <div class="locker-card-footer">
                <button class="edit-btn" onclick="editLocker(${locker.id})">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="delete-btn" onclick="deleteLocker(${locker.id})">
                    <i class="fas fa-trash"></i> Hapus
                </button>
            </div>
        </div>
    `;
}

// ==================== TABLE ACTIONS ====================
function initTableActions() {
    // View user buttons
    document.querySelectorAll('.action-btn.view').forEach(btn => {
        btn.addEventListener('click', function () {
            const row = this.closest('tr');
            viewUser(row);
        });
    });

    // Edit user buttons
    document.querySelectorAll('.action-btn.edit').forEach(btn => {
        btn.addEventListener('click', function () {
            const row = this.closest('tr');
            editUser(row);
        });
    });

    // Delete user buttons
    document.querySelectorAll('.action-btn.delete').forEach(btn => {
        btn.addEventListener('click', function () {
            const row = this.closest('tr');
            deleteUser(row);
        });
    });
}

function viewUser(row) {
    if (!row) return;
    const cells = row.querySelectorAll('td');

    const modal = document.getElementById('viewUserModal');
    if (modal) {
        document.getElementById('viewUserName').textContent = cells[1]?.textContent?.trim() || '-';
        document.getElementById('viewUserNim').textContent = cells[2]?.textContent?.trim() || '-';
        document.getElementById('viewUserEmail').textContent = cells[3]?.textContent?.trim() || '-';
        document.getElementById('viewUserLocker').textContent = cells[4]?.textContent?.trim() || '-';
        document.getElementById('viewUserDate').textContent = cells[5]?.textContent?.trim() || '-';
        showModal('viewUserModal');
    } else {
        showToast('Detail pengguna: ' + (cells[1]?.textContent?.trim() || 'N/A'), 'info');
    }
}

function editUser(row) {
    showToast('Fitur edit pengguna sedang dalam pengembangan', 'info');
}

function deleteUser(row) {
    if (!row) return;
    const name = row.querySelector('td:nth-child(2)')?.textContent?.trim() || 'pengguna ini';

    if (confirm(`Apakah Anda yakin ingin menghapus ${name}?`)) {
        row.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => {
            row.remove();
            showToast('Pengguna berhasil dihapus', 'success');
        }, 300);
    }
}

// ==================== EXPORT BUTTONS ====================
function initExportButtons() {
    // Add click handlers to report buttons
    document.querySelectorAll('.report-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const reportType = this.closest('.report-card').querySelector('h3').textContent;
            generateReport(reportType);
        });
    });

    // Export button in transactions
    document.querySelectorAll('.secondary-btn').forEach(btn => {
        if (btn.textContent.includes('Export')) {
            btn.addEventListener('click', function () {
                showExportModal();
            });
        }
    });
}

function generateReport(reportType) {
    showToast(`Generating ${reportType}...`, 'info');

    setTimeout(() => {
        showToast(`${reportType} berhasil di-generate!`, 'success');
        // Simulate download
        const blob = new Blob([`Report: ${reportType}\nGenerated: ${new Date().toLocaleString()}`], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${reportType.replace(/\s/g, '_')}_${Date.now()}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    }, 1500);
}

function showExportModal() {
    const modal = document.getElementById('exportModal');
    if (modal) {
        showModal('exportModal');
    } else {
        performExport();
    }
}

function performExport() {
    const format = document.querySelector('input[name="exportFormat"]:checked')?.value || 'excel';

    showToast(`Mengexport data ke format ${format.toUpperCase()}...`, 'info');

    setTimeout(() => {
        showToast('Export berhasil!', 'success');
        hideModal('exportModal');
    }, 1500);
}

// ==================== MODAL FUNCTIONS ====================
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }
}

// Close modal when clicking overlay
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('show');
        document.body.style.overflow = '';
    }
});

// ==================== LOGOUT FUNCTIONS ====================
function confirmLogout() {
    const modal = document.getElementById('confirmLogoutModal');
    if (modal) {
        showModal('confirmLogoutModal');
    } else {
        if (confirm('Apakah Anda yakin ingin logout?')) {
            performLogout();
        }
    }
}

function performLogout() {
    localStorage.removeItem('adminLoggedIn');
    localStorage.removeItem('adminName');
    showToast('Logout berhasil. Mengalihkan...', 'success');

    setTimeout(() => {
        window.location.href = 'admin-login.html';
    }, 1000);
}

// ==================== PROFILE FUNCTIONS ====================
function saveProfile() {
    const name = document.getElementById('profileName')?.value;
    const email = document.getElementById('profileEmail')?.value;

    if (name) {
        localStorage.setItem('adminName', name);

        // Update UI
        document.querySelectorAll('.admin-name, #adminName, #dropdownAdminName').forEach(el => {
            if (el) el.textContent = name;
        });
    }

    hideModal('profileModal');
    showToast('Profil berhasil diperbarui', 'success');
}

function exportActivityLog() {
    showToast('Mengexport log aktivitas...', 'info');
    setTimeout(() => {
        showToast('Log aktivitas berhasil diexport!', 'success');
    }, 1000);
}

// ==================== LOCKER ACTIONS ====================
function editLocker(id) {
    showToast(`Mengedit Locker #${id}`, 'info');
    showModal('addLockerModal');
}

function deleteLocker(id) {
    if (confirm(`Apakah Anda yakin ingin menghapus Locker #${id}?`)) {
        showToast(`Locker #${id} berhasil dihapus`, 'success');
        initLockerManagement(); // Refresh grid
    }
}

// ==================== PRINT FUNCTION ====================
function printReport() {
    window.print();
}

// ==================== UTILITY FUNCTIONS ====================
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func.apply(this, args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ==================== SEARCH FUNCTIONALITY ====================
document.querySelectorAll('.search-box input, .search-filter input').forEach(input => {
    input.addEventListener('input', debounce(function (e) {
        const query = e.target.value.toLowerCase();
        if (query.length > 0) {
            showToast(`Mencari: "${query}"`, 'info');
        }
    }, 500));
});

// ==================== KEYBOARD SHORTCUTS ====================
document.addEventListener('keydown', (e) => {
    // Escape to close modals
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.show').forEach(modal => {
            modal.classList.remove('show');
            document.body.style.overflow = '';
        });
    }

    // Ctrl+K for search
    if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        const searchInput = document.querySelector('.search-box input');
        if (searchInput) searchInput.focus();
    }

    // Ctrl+P for print
    if (e.ctrlKey && e.key === 'p') {
        e.preventDefault();
        printReport();
    }
});

// ==================== TOAST NOTIFICATIONS ====================
function showToast(message, type = 'info') {
    // Create container if not exists
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        container.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
        `;
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const icons = {
        success: 'fa-check-circle',
        error: 'fa-times-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };

    const colors = {
        success: '#4ade80',
        error: '#f87171',
        warning: '#fbbf24',
        info: '#5B86E5'
    };

    toast.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i><span>${message}</span>`;
    toast.style.cssText = `
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 15px 20px;
        background: ${colors[type] || colors.info};
        color: white;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
        animation: slideInRight 0.3s ease;
        font-size: 14px;
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'slideOutRight 0.3s ease forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Add animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
`;
document.head.appendChild(style);

// ==================== ANIMATION ON SCROLL ====================
const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

document.querySelectorAll('.stat-card, .chart-card, .activity-card, .quick-actions-card').forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'all 0.5s ease';
    observer.observe(card);
});

// Admin Dashboard Enhanced - Ready
