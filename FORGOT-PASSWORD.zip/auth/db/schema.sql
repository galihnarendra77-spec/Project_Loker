-- Forgot Password System Database Schema
-- MariaDB / MySQL

-- Create database (run this first)
CREATE DATABASE IF NOT EXISTS forgot_password_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE forgot_password_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample user for testing (password: TestPassword123!)
-- You can use this user to test the forgot password flow
INSERT INTO users (email, password_hash) VALUES 
('test@example.com', '$2a$10$XQjZY5Z5Z5Z5Z5Z5Z5Z5ZeF5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z5Z')
ON DUPLICATE KEY UPDATE email=email;
