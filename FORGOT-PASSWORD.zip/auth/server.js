const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const { pool, testConnection } = require('./config/database');
const { client: redisClient, connectRedis } = require('./config/redis');
const { verifyEmailConnection, sendOTPEmail } = require('./config/email');

const app = express();
const PORT = process.env.PORT || 3000;
const OTP_EXPIRY = parseInt(process.env.OTP_EXPIRY_SECONDS) || 60; // 1 minute

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Generate 6-digit OTP
function generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// API Endpoints

// 1. Request Password Reset - Send OTP via Email
app.post('/api/forgot-password', async (req, res) => {
    const { email } = req.body;

    try {
        // Validate email
        if (!email || !email.includes('@')) {
            return res.status(400).json({
                success: false,
                message: 'Email tidak valid'
            });
        }

        // Check if user exists in database
        const [users] = await pool.query('SELECT id, email FROM users WHERE email = ?', [email]);

        if (users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Email tidak terdaftar'
            });
        }

        // Generate OTP
        const otp = generateOTP();

        // Store OTP in Redis with expiry
        const redisKey = `otp:${email}`;
        await redisClient.setEx(redisKey, OTP_EXPIRY, otp);

        // Send OTP via email
        await sendOTPEmail(email, otp);

        console.log(`🔑 OTP generated for ${email}: ${otp} (expires in ${OTP_EXPIRY}s)`);

        res.json({
            success: true,
            message: 'Kode OTP telah dikirim ke email Anda',
            expirySeconds: OTP_EXPIRY
        });

    } catch (error) {
        console.error('Error in forgot-password:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengirim OTP'
        });
    }
});

// 2. Verify OTP
app.post('/api/verify-otp', async (req, res) => {
    const { email, otp } = req.body;

    try {
        // Validate input
        if (!email || !otp) {
            return res.status(400).json({
                success: false,
                message: 'Email dan OTP harus diisi'
            });
        }

        // Get OTP from Redis
        const redisKey = `otp:${email}`;
        const storedOTP = await redisClient.get(redisKey);

        if (!storedOTP) {
            return res.status(400).json({
                success: false,
                message: 'Kode OTP sudah kadaluarsa atau tidak valid'
            });
        }

        // Verify OTP
        if (storedOTP !== otp) {
            return res.status(400).json({
                success: false,
                message: 'Kode OTP salah'
            });
        }

        // OTP is valid - mark as verified in Redis (keep for password reset)
        await redisClient.setEx(`verified:${email}`, 300, 'true'); // 5 minutes to reset password

        res.json({
            success: true,
            message: 'Kode OTP berhasil diverifikasi'
        });

    } catch (error) {
        console.error('Error in verify-otp:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat verifikasi OTP'
        });
    }
});

// 3. Resend OTP
app.post('/api/resend-otp', async (req, res) => {
    const { email } = req.body;

    try {
        // Validate email
        if (!email || !email.includes('@')) {
            return res.status(400).json({
                success: false,
                message: 'Email tidak valid'
            });
        }

        // Check if user exists
        const [users] = await pool.query('SELECT id, email FROM users WHERE email = ?', [email]);

        if (users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Email tidak terdaftar'
            });
        }

        // Generate new OTP
        const otp = generateOTP();

        // Store OTP in Redis with expiry (overwrites old one)
        const redisKey = `otp:${email}`;
        await redisClient.setEx(redisKey, OTP_EXPIRY, otp);

        // Send OTP via email
        await sendOTPEmail(email, otp);

        console.log(`🔑 OTP resent for ${email}: ${otp} (expires in ${OTP_EXPIRY}s)`);

        res.json({
            success: true,
            message: 'Kode OTP baru telah dikirim ke email Anda',
            expirySeconds: OTP_EXPIRY
        });

    } catch (error) {
        console.error('Error in resend-otp:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengirim ulang OTP'
        });
    }
});

// 4. Reset Password
app.post('/api/reset-password', async (req, res) => {
    const { email, newPassword } = req.body;

    try {
        // Validate input
        if (!email || !newPassword) {
            return res.status(400).json({
                success: false,
                message: 'Email dan password baru harus diisi'
            });
        }

        // Check password strength
        if (newPassword.length < 8) {
            return res.status(400).json({
                success: false,
                message: 'Password minimal 8 karakter'
            });
        }

        // Check if OTP was verified
        const verifiedKey = `verified:${email}`;
        const isVerified = await redisClient.get(verifiedKey);

        if (!isVerified) {
            return res.status(400).json({
                success: false,
                message: 'Silakan verifikasi OTP terlebih dahulu'
            });
        }

        // Hash new password
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        // Update password in database
        const [result] = await pool.query(
            'UPDATE users SET password_hash = ?, updated_at = NOW() WHERE email = ?',
            [hashedPassword, email]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Email tidak terdaftar'
            });
        }

        // Clean up Redis keys
        await redisClient.del(`otp:${email}`);
        await redisClient.del(`verified:${email}`);

        console.log(`✅ Password reset successful for ${email}`);

        res.json({
            success: true,
            message: 'Password berhasil direset'
        });

    } catch (error) {
        console.error('Error in reset-password:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mereset password'
        });
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        message: 'Server is running',
        timestamp: new Date().toISOString()
    });
});

// Initialize server
async function startServer() {
    try {
        // Test database connection
        await testConnection();

        // Connect to Redis
        await connectRedis();

        // Verify email connection
        await verifyEmailConnection();

        // Start Express server
        app.listen(PORT, () => {
            console.log(`\n🚀 Server running on http://localhost:${PORT}`);
            console.log(`📱 Frontend: http://localhost:${PORT}`);
            console.log(`🔌 API: http://localhost:${PORT}/api`);
        });
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
}

startServer();
