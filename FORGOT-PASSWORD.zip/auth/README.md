# 🔐 Forgot Password Authentication System with OTP

Modern, secure forgot password flow with email-based OTP verification. Features a beautiful glassmorphism UI, 1-minute OTP expiry, Redis caching, MariaDB storage, and Gmail SMTP integration.

## ✨ Features

- **🎨 Modern UI**: Beautiful glassmorphism design with smooth animations
- **📧 Email OTP**: Secure 6-digit OTP sent via Gmail SMTP
- **⏱️ Time-Limited**: OTP expires after 1 minute for security
- **🔄 Resend Capability**: Users can request new OTP if expired
- **📱 Responsive**: Works perfectly on all devices
- **🔒 Secure**: Password hashing with bcrypt, Redis caching

## 🛠️ Tech Stack

- **Backend**: Node.js, Express.js
- **Database**: MariaDB/MySQL
- **Cache**: Redis
- **Email**: Nodemailer (Gmail SMTP)
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Security**: bcryptjs for password hashing

## 📋 Prerequisites

Before running this application, ensure you have:

- **Node.js** (v14 or higher)
- **MariaDB/MySQL** database server
- **Redis** server
- **Gmail account** with App Password enabled

## 🚀 Installation

### 1. Clone and Install Dependencies

```bash
cd c:\Users\USER\.gemini\antigravity\playground\midnight-granule
npm install
```

### 2. Configure Gmail SMTP

To send emails, you need a Gmail App Password:

1. Go to your [Google Account](https://myaccount.google.com/)
2. Navigate to **Security**
3. Enable **2-Step Verification** (if not already enabled)
4. Go to **App Passwords** (search for "App Passwords" in settings)
5. Select **Mail** and **Windows Computer** (or Other)
6. Click **Generate**
7. Copy the 16-character password (you'll use this in `.env`)

### 3. Set Up Database

Run the schema file to create the database and tables:

```bash
# Login to MariaDB/MySQL
mysql -u root -p

# Run the schema
source db/schema.sql

# Or manually:
mysql -u root -p < db/schema.sql
```

### 4. Configure Environment Variables

Copy the example environment file and edit it:

```bash
cp .env.example .env
```

Edit `.env` with your actual credentials:

```env
# Server Configuration
PORT=3000

# MariaDB Configuration
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_actual_database_password
DB_NAME=forgot_password_db

# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# Gmail SMTP Configuration
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_gmail@gmail.com
SMTP_PASSWORD=your_16_char_app_password
SMTP_FROM=your_gmail@gmail.com

# OTP Configuration
OTP_EXPIRY_SECONDS=60
```

### 5. Start Redis

Make sure Redis is running:

```bash
# Windows (if installed via Memurai or Redis for Windows)
redis-server

# Or check if it's already running
redis-cli ping
# Should return: PONG
```

### 6. Start the Application

```bash
npm start

# Or for development with auto-reload:
npm run dev
```

The application will be available at: **http://localhost:3000**

## 📖 API Endpoints

### 1. Request Password Reset (Send OTP)
```http
POST /api/forgot-password
Content-Type: application/json

{
  "email": "user@example.com"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Kode OTP telah dikirim ke email Anda",
  "expirySeconds": 60
}
```

### 2. Verify OTP
```http
POST /api/verify-otp
Content-Type: application/json

{
  "email": "user@example.com",
  "otp": "123456"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Kode OTP berhasil diverifikasi"
}
```

### 3. Resend OTP
```http
POST /api/resend-otp
Content-Type: application/json

{
  "email": "user@example.com"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Kode OTP baru telah dikirim ke email Anda",
  "expirySeconds": 60
}
```

### 4. Reset Password
```http
POST /api/reset-password
Content-Type: application/json

{
  "email": "user@example.com",
  "newPassword": "NewPassword123!"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Password berhasil direset"
}
```

### 5. Health Check
```http
GET /api/health
```

**Response:**
```json
{
  "status": "OK",
  "message": "Server is running",
  "timestamp": "2024-12-02T12:00:00.000Z"
}
```

## 🎯 User Flow

1. **Email Input**: User enters their email address
2. **OTP Sent**: System sends 6-digit OTP via email (valid for 60 seconds)
3. **OTP Verification**: User enters OTP code
4. **Password Reset**: After verification, user sets new password
5. **Success**: Password updated successfully

## 🔒 Security Features

- **Bcrypt Hashing**: Passwords are hashed with bcrypt (salt rounds: 10)
- **OTP Expiry**: OTP codes expire after 60 seconds
- **Redis Storage**: OTP stored in Redis with automatic expiry
- **Email Verification**: Only registered email addresses can reset passwords
- **Secure Transport**: SMTP uses TLS encryption

## 🎨 UI Features

- **Glassmorphism Design**: Modern glass effect with backdrop blur
- **Animated Background**: Dynamic gradient shapes
- **Countdown Timer**: Real-time OTP expiration countdown
- **Auto-focus**: Smart input focus management
- **Password Toggle**: Show/hide password functionality
- **Toast Notifications**: User-friendly success/error messages
- **Responsive**: Mobile-first, works on all screen sizes
- **Smooth Animations**: CSS transitions and keyframe animations

## 🧪 Testing

### Test User
The database schema includes a test user:
- **Email**: `test@example.com`
- **Password**: `TestPassword123!` (hashed)

### Testing Steps:
1. Visit http://localhost:3000
2. Enter `test@example.com`
3. Check your Gmail inbox for OTP
4. Enter the 6-digit OTP code
5. Set a new password
6. Success!

## 📁 Project Structure

```
midnight-granule/
├── config/
│   ├── database.js      # MariaDB connection pool
│   ├── redis.js         # Redis client configuration
│   └── email.js         # Gmail SMTP & email templates
├── db/
│   └── schema.sql       # Database schema
├── public/
│   ├── index.html       # Frontend UI
│   ├── styles.css       # Modern CSS styling
│   └── script.js        # Client-side logic
├── .env.example         # Environment variables template
├── .env                 # Your actual environment variables (create this)
├── package.json         # Dependencies
├── server.js            # Express server & API endpoints
└── README.md            # This file
```

## 🐛 Troubleshooting

### Email Not Sending
- Verify Gmail App Password is correct
- Check if 2-Step Verification is enabled
- Ensure SMTP credentials in `.env` are correct
- Check firewall/antivirus blocking port 587

### Redis Connection Error
- Make sure Redis server is running
- Check Redis connection details in `.env`
- Try: `redis-cli ping` (should return PONG)

### Database Connection Error
- Verify MariaDB/MySQL is running
- Check database credentials in `.env`
- Ensure database `forgot_password_db` exists
- Run `db/schema.sql` to create tables

### OTP Expired Too Quickly
- Default is 60 seconds (1 minute)
- Increase `OTP_EXPIRY_SECONDS` in `.env` for testing
- Recommended: 300 seconds (5 minutes) for production

## 📝 License

MIT License - Feel free to use this project for learning or production!

## 🤝 Contributing

Contributions are welcome! Feel free to submit issues or pull requests.

---

**Built with ❤️ using Node.js, Express, MariaDB, Redis, and Gmail SMTP**
