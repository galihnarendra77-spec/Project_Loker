const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const authRoutes = require('./routes/auth.routes');
const { verifyEmailConfig } = require('./config/email.config');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// API Routes
app.use('/api/auth', authRoutes);

// Root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        message: 'Terjadi kesalahan server'
    });
});

// Start server
async function startServer() {
    // Verify email configuration
    const emailReady = await verifyEmailConfig();

    if (!emailReady) {
        console.warn('⚠️  Warning: Email not configured properly. Please check .env file.');
        console.warn('    Create .env file based on .env.example');
    }

    app.listen(PORT, () => {
        console.log('=================================');
        console.log(`🚀 Server running on port ${PORT}`);
        console.log(`📧 Email service: ${process.env.EMAIL_SERVICE || 'Not configured'}`);
        console.log(`🌐 Open: http://localhost:${PORT}`);
        console.log('=================================');
    });
}

startServer();
