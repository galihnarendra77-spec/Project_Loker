const nodemailer = require('nodemailer');
require('dotenv').config();

/**
 * Create email transporter for Gmail with TLS/SSL encryption
 */
const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE || 'gmail',
  // Enable SSL/TLS encryption
  secure: true, // Use SSL (port 465)
  port: 465,    // SSL port
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  },
  // Additional security settings
  tls: {
    // Do not fail on invalid certificates (untuk development)
    // Untuk production, set ke true
    rejectUnauthorized: false,
    minVersion: 'TLSv1.2' // Minimal TLS versi 1.2
  }
});

/**
 * Generate beautiful HTML email template for OTP
 */
function getOTPEmailTemplate(otp, appName) {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Kode OTP Anda</title>
      <style>
        body {
          margin: 0;
          padding: 0;
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .container {
          max-width: 600px;
          margin: 40px auto;
          background: #ffffff;
          border-radius: 20px;
          overflow: hidden;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        .header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 40px 30px;
          text-align: center;
          color: white;
        }
        .header h1 {
          margin: 0;
          font-size: 28px;
          font-weight: 700;
        }
        .content {
          padding: 40px 30px;
          text-align: center;
        }
        .content p {
          font-size: 16px;
          color: #4a5568;
          line-height: 1.6;
          margin-bottom: 30px;
        }
        .otp-box {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 20px;
          border-radius: 12px;
          display: inline-block;
          margin: 20px 0;
        }
        .otp-code {
          font-size: 42px;
          font-weight: 700;
          color: white;
          letter-spacing: 8px;
          margin: 0;
        }
        .footer {
          padding: 30px;
          text-align: center;
          background: #f7fafc;
          border-top: 1px solid #e2e8f0;
        }
        .footer p {
          margin: 5px 0;
          font-size: 14px;
          color: #718096;
        }
        .warning {
          margin-top: 30px;
          padding: 15px;
          background: #fff5f5;
          border-left: 4px solid #f56565;
          border-radius: 4px;
        }
        .warning p {
          margin: 0;
          font-size: 14px;
          color: #c53030;
          text-align: left;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🔐 ${appName}</h1>
        </div>
        <div class="content">
          <p>Hai! Anda telah meminta kode OTP untuk autentikasi.</p>
          <p style="font-size: 18px; font-weight: 600; color: #2d3748;">Gunakan kode berikut untuk verifikasi:</p>
          <div class="otp-box">
            <p class="otp-code">${otp}</p>
          </div>
          <p style="font-size: 14px; color: #718096;">Kode ini berlaku selama <strong>1 menit</strong></p>
          <div class="warning">
            <p>⚠️ <strong>Jangan bagikan kode ini kepada siapa pun!</strong> Tim kami tidak akan pernah meminta kode OTP Anda.</p>
          </div>
        </div>
        <div class="footer">
          <p>Email ini dikirim secara otomatis, mohon tidak membalas.</p>
          <p style="color: #48bb78; font-weight: 600;">🔒 Email dikirim dengan enkripsi TLS/SSL untuk keamanan Anda</p>
          <p>&copy; 2024 ${appName}. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `;
}

/**
 * Send OTP email to user with encryption (TLS/SSL)
 */
async function sendOTPEmail(email, otp) {
  const appName = process.env.APP_NAME || 'OTP Auth System';

  const mailOptions = {
    from: `"${appName}" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: `Kode OTP Anda: ${otp}`,
    html: getOTPEmailTemplate(otp, appName),
    // Security headers
    headers: {
      'X-Priority': '1',
      'X-MSMail-Priority': 'High',
      'Importance': 'high',
      'X-Mailer': 'OTP Auth System - Encrypted',
      // Prevent email content indexing
      'X-Robots-Tag': 'noindex, nofollow'
    }
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log('✅ Email sent securely (TLS/SSL encrypted):', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ Error sending email:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Verify email configuration
 */
async function verifyEmailConfig() {
  try {
    await transporter.verify();
    console.log('✅ Email server is ready (Encrypted with TLS/SSL)');
    return true;
  } catch (error) {
    console.error('❌ Email configuration error:', error.message);
    return false;
  }
}

module.exports = {
  sendOTPEmail,
  verifyEmailConfig
};
