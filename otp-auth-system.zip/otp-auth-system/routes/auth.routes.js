const express = require('express');
const router = express.Router();
const { storeOTP, verifyOTP } = require('../utils/otp');
const { sendOTPEmail } = require('../config/email.config');

/**
 * POST /api/auth/send-otp
 * Send OTP to user's email
 */
router.post('/send-otp', async (req, res) => {
    try {
        const { email } = req.body;

        // Validate email
        if (!email) {
            return res.status(400).json({
                success: false,
                message: 'Email diperlukan'
            });
        }

        // Basic email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: 'Format email tidak valid'
            });
        }

        // Generate and store OTP
        const otp = storeOTP(email);

        // Send OTP via email
        const emailResult = await sendOTPEmail(email, otp);

        if (!emailResult.success) {
            return res.status(500).json({
                success: false,
                message: 'Gagal mengirim email. Pastikan konfigurasi email sudah benar.'
            });
        }

        res.json({
            success: true,
            message: 'OTP berhasil dikirim ke email Anda',
            expiresIn: '1 menit'
        });

    } catch (error) {
        console.error('Send OTP error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan server'
        });
    }
});

/**
 * POST /api/auth/verify-otp
 * Verify OTP and authenticate user
 */
router.post('/verify-otp', (req, res) => {
    try {
        const { email, otp } = req.body;

        // Validate input
        if (!email || !otp) {
            return res.status(400).json({
                success: false,
                message: 'Email dan OTP diperlukan'
            });
        }

        // Verify OTP
        const result = verifyOTP(email, otp);

        if (!result.valid) {
            return res.status(400).json({
                success: false,
                message: result.message
            });
        }

        // OTP is valid - in a real app, you would create a session/token here
        res.json({
            success: true,
            message: result.message,
            user: {
                email: email
            }
            // In production, return a JWT token or session ID here
        });

    } catch (error) {
        console.error('Verify OTP error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan server'
        });
    }
});

module.exports = router;
