// API Base URL
const API_BASE_URL = '/api/auth';

// State
let currentEmail = '';

// DOM Elements
const emailForm = document.getElementById('emailForm');
const otpForm = document.getElementById('otpForm');
const successScreen = document.getElementById('successScreen');
const emailFormElement = document.getElementById('emailFormElement');
const otpFormElement = document.getElementById('otpFormElement');
const emailInput = document.getElementById('email');
const otpDigits = document.querySelectorAll('.otp-digit');
const sendOTPBtn = document.getElementById('sendOTPBtn');
const verifyOTPBtn = document.getElementById('verifyOTPBtn');
const backBtn = document.getElementById('backBtn');
const resendBtn = document.getElementById('resendBtn');
const logoutBtn = document.getElementById('logoutBtn');
const toast = document.getElementById('toast');
const otpSentMessage = document.getElementById('otpSentMessage');
const userEmailDisplay = document.getElementById('userEmail');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    setupOTPInputs();
});

// Event Listeners
function setupEventListeners() {
    emailFormElement.addEventListener('submit', handleEmailSubmit);
    otpFormElement.addEventListener('submit', handleOTPSubmit);
    backBtn.addEventListener('click', goBackToEmailForm);
    resendBtn.addEventListener('click', handleResendOTP);
    logoutBtn.addEventListener('click', handleLogout);
}

// OTP Input Auto-focus and Formatting
function setupOTPInputs() {
    otpDigits.forEach((input, index) => {
        // Auto-focus next input
        input.addEventListener('input', (e) => {
            const value = e.target.value;

            // Only allow numbers
            if (!/^\d*$/.test(value)) {
                e.target.value = '';
                return;
            }

            // Move to next input if value entered
            if (value && index < otpDigits.length - 1) {
                otpDigits[index + 1].focus();
            }
        });

        // Handle backspace
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Backspace' && !e.target.value && index > 0) {
                otpDigits[index - 1].focus();
            }
        });

        // Handle paste
        input.addEventListener('paste', (e) => {
            e.preventDefault();
            const pastedData = e.clipboardData.getData('text').trim();

            // Only process if it's 6 digits
            if (/^\d{6}$/.test(pastedData)) {
                pastedData.split('').forEach((char, i) => {
                    if (otpDigits[i]) {
                        otpDigits[i].value = char;
                    }
                });
                otpDigits[5].focus();
            }
        });
    });
}

// Handle Email Form Submission
async function handleEmailSubmit(e) {
    e.preventDefault();

    const email = emailInput.value.trim();

    if (!email) {
        showToast('Silakan masukkan email Anda', 'error');
        return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showToast('Format email tidak valid', 'error');
        return;
    }

    currentEmail = email;
    setButtonLoading(sendOTPBtn, true);

    try {
        const response = await fetch(`${API_BASE_URL}/send-otp`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email })
        });

        const data = await response.json();

        if (data.success) {
            showToast('Kode OTP berhasil dikirim!', 'success');
            otpSentMessage.textContent = `Kode OTP telah dikirim ke ${maskEmail(email)}`;
            showOTPForm();
        } else {
            showToast(data.message || 'Gagal mengirim OTP', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Terjadi kesalahan. Silakan coba lagi.', 'error');
    } finally {
        setButtonLoading(sendOTPBtn, false);
    }
}

// Handle OTP Form Submission
async function handleOTPSubmit(e) {
    e.preventDefault();

    const otp = Array.from(otpDigits).map(input => input.value).join('');

    if (otp.length !== 6) {
        showToast('Silakan masukkan kode OTP 6 digit', 'error');
        return;
    }

    setButtonLoading(verifyOTPBtn, true);

    try {
        const response = await fetch(`${API_BASE_URL}/verify-otp`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: currentEmail,
                otp
            })
        });

        const data = await response.json();

        if (data.success) {
            showToast('Verifikasi berhasil!', 'success');
            userEmailDisplay.textContent = currentEmail;
            showSuccessScreen();
        } else {
            showToast(data.message || 'Kode OTP tidak valid', 'error');
            // Clear OTP inputs on error
            otpDigits.forEach(input => input.value = '');
            otpDigits[0].focus();
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Terjadi kesalahan. Silakan coba lagi.', 'error');
    } finally {
        setButtonLoading(verifyOTPBtn, false);
    }
}

// Handle Resend OTP
async function handleResendOTP() {
    if (!currentEmail) return;

    try {
        const response = await fetch(`${API_BASE_URL}/send-otp`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: currentEmail })
        });

        const data = await response.json();

        if (data.success) {
            showToast('Kode OTP baru telah dikirim!', 'success');
            // Clear OTP inputs
            otpDigits.forEach(input => input.value = '');
            otpDigits[0].focus();
        } else {
            showToast(data.message || 'Gagal mengirim OTP', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Terjadi kesalahan. Silakan coba lagi.', 'error');
    }
}

// Handle Logout
function handleLogout() {
    currentEmail = '';
    emailInput.value = '';
    otpDigits.forEach(input => input.value = '');
    goBackToEmailForm();
}

// Navigation Functions
function showOTPForm() {
    emailForm.style.display = 'none';
    otpForm.style.display = 'block';
    successScreen.style.display = 'none';

    // Focus first OTP input
    setTimeout(() => otpDigits[0].focus(), 100);

    // Animate card
    otpForm.style.animation = 'none';
    setTimeout(() => {
        otpForm.style.animation = 'fadeInUp 0.5s ease-out';
    }, 10);
}

function showSuccessScreen() {
    emailForm.style.display = 'none';
    otpForm.style.display = 'none';
    successScreen.style.display = 'block';

    // Animate card
    successScreen.style.animation = 'none';
    setTimeout(() => {
        successScreen.style.animation = 'fadeInUp 0.5s ease-out';
    }, 10);
}

function goBackToEmailForm() {
    emailForm.style.display = 'block';
    otpForm.style.display = 'none';
    successScreen.style.display = 'none';

    // Clear OTP inputs
    otpDigits.forEach(input => input.value = '');

    // Animate card
    emailForm.style.animation = 'none';
    setTimeout(() => {
        emailForm.style.animation = 'fadeInUp 0.5s ease-out';
    }, 10);
}

// UI Helper Functions
function setButtonLoading(button, isLoading) {
    const btnText = button.querySelector('.btn-text');
    const btnLoader = button.querySelector('.btn-loader');

    if (isLoading) {
        btnText.style.display = 'none';
        btnLoader.style.display = 'inline-block';
        button.disabled = true;
    } else {
        btnText.style.display = 'inline';
        btnLoader.style.display = 'none';
        button.disabled = false;
    }
}

function showToast(message, type = 'success') {
    const toastMessage = toast.querySelector('.toast-message');
    const successIcon = toast.querySelector('.toast-icon-success');
    const errorIcon = toast.querySelector('.toast-icon-error');

    // Set message
    toastMessage.textContent = message;

    // Set type
    toast.className = `toast ${type}`;

    // Show appropriate icon
    if (type === 'success') {
        successIcon.style.display = 'block';
        errorIcon.style.display = 'none';
    } else {
        successIcon.style.display = 'none';
        errorIcon.style.display = 'block';
    }

    // Show toast
    toast.style.display = 'block';
    toast.style.animation = 'slideInRight 0.3s ease-out';

    // Hide after 4 seconds
    setTimeout(() => {
        toast.style.animation = 'slideInRight 0.3s ease-out reverse';
        setTimeout(() => {
            toast.style.display = 'none';
        }, 300);
    }, 4000);
}

function maskEmail(email) {
    const [username, domain] = email.split('@');
    const maskedUsername = username.length > 3
        ? username.substring(0, 2) + '***' + username.substring(username.length - 1)
        : username.substring(0, 1) + '***';
    return `${maskedUsername}@${domain}`;
}
