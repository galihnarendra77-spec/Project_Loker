// In-memory storage for OTPs
// Structure: { email: { otp: '123456', expiresAt: timestamp } }
const otpStorage = new Map();

/**
 * Generate a random 6-digit OTP
 */
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * Store OTP for an email with expiration time
 * @param {string} email - User's email address
 * @param {number} expiryMinutes - OTP expiry time in minutes (default: 5)
 */
function storeOTP(email, expiryMinutes = 5) {
  const otp = generateOTP();
  const expiresAt = Date.now() + expiryMinutes * 60 * 1000;

  otpStorage.set(email.toLowerCase(), {
    otp,
    expiresAt
  });

  // Auto-cleanup after expiry
  setTimeout(() => {
    otpStorage.delete(email.toLowerCase());
  }, expiryMinutes * 60 * 1000);

  return otp;
}

/**
 * Verify OTP for an email
 * @param {string} email - User's email address
 * @param {string} otp - OTP to verify
 * @returns {Object} - { valid: boolean, message: string }
 */
function verifyOTP(email, otp) {
  const normalizedEmail = email.toLowerCase();
  const stored = otpStorage.get(normalizedEmail);

  if (!stored) {
    return { valid: false, message: 'OTP tidak ditemukan atau sudah kedaluwarsa' };
  }

  if (Date.now() > stored.expiresAt) {
    otpStorage.delete(normalizedEmail);
    return { valid: false, message: 'OTP sudah kedaluwarsa' };
  }

  if (stored.otp !== otp) {
    return { valid: false, message: 'OTP tidak valid' };
  }

  // OTP is valid, remove it (one-time use)
  otpStorage.delete(normalizedEmail);
  return { valid: true, message: 'OTP berhasil diverifikasi' };
}

module.exports = {
  generateOTP,
  storeOTP,
  verifyOTP
};
